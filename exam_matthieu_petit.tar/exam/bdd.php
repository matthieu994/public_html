<?php
session_start();
$db = new mysqli("localhost", "petitm", "21706050", "exam");
$db->set_charset("utf8");
?>
