<?php
$nom=["Snoopy", "Tina", "Sam", "Sally", "Ulysse", "Chipie", "Rocky", "Roxane", "Max", "Princesse", "Lady", "Oscar", "Ugo", "Tequila", "Simba", "Ramses", "Teddy", "Titus", "Maya", "Tania", "Samy", "Filou", "Tomy", "Lucky", "Junior", "Socrate", "Vanille", "Gribouille", "Choupette", "Nina", "Sandy", "Saphir", "Tara", "Lola" ];
?>
