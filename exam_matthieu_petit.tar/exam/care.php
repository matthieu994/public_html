<!doctype html>
<html>
<head>
   <title> Tamagotchi </title>
   <link rel="shortcut icon" href="fav.ico">
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <link rel="stylesheet" href="https://cdn.concisecss.com/concise.min.css">
   <link rel="stylesheet" href="https://cdn.concisecss.com/concise-utils/concise-utils.min.css">
   <link rel="stylesheet" href="https://cdn.concisecss.com/concise-ui/concise-ui.min.css">
   <link rel="stylesheet" href="index.css">
</head>
<body>
</ul>

</body>
<script src="care.js">
</script>
<?php echo '<script>reload('. $_GET['tama'] .')</script>' ?>
</html>
